Este archivo contiene instrucciones adicionales para la entrega de la evidencia.
